import Database from "better-sqlite3";
const db = new Database("coinbook.db");

db.pragma("journal_mode = WAL");

db.exec(`
create table if not exists users(
  id integer primary key autoincrement,
  username text unique not null,
  email text,
  phone text,
  password_hash text not null,
  coins real not null default 100,
  created_at text not null
);

create table if not exists bets(
  id integer primary key autoincrement,
  sport text not null,
  event text not null,
  market text not null,
  selection text not null,
  odds_decimal real not null check(odds_decimal > 1.01),
  status text not null default 'open' check(status in ('open','settled','void')),
  result text,
  starts_at text not null
);

create table if not exists wagers(
  id integer primary key autoincrement,
  user_id integer not null references users(id),
  bet_id integer not null references bets(id),
  stake integer not null,
  potential_payout real not null,
  status text not null check(status in ('pending','won','lost','void')),
  placed_at text not null,
  settled_at text
);

create table if not exists meta(
  key text primary key,
  value text not null
);
`);
export default db;