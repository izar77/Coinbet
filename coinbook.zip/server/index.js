import express from "express";
import morgan from "morgan";
import cors from "cors";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import db from "./sqlite.js";

const app = express();
const PORT = process.env.PORT || 4321;
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

app.use(morgan("dev"));
app.use(cors());
app.use(express.json());

function signToken(user) {
  return jwt.sign({ uid: user.id, u: user.username }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "invalid token" });
  }
}

app.post("/api/signup", (req, res) => {
  const { username, email, phone, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username and password required" });
  if (db.prepare("select 1 from users where username = ?").get(username)) {
    return res.status(409).json({ error: "username taken" });
  }
  const hash = bcrypt.hashSync(password, 10);
  const coinsStart = 100;
  const info = db
    .prepare("insert into users (username,email,phone,password_hash,coins,created_at) values (?,?,?,?,?,datetime('now'))")
    .run(username, email || null, phone || null, hash, coinsStart);
  const user = db.prepare("select id, username, coins from users where id = ?").get(info.lastInsertRowid);
  res.json({ token: signToken(user), user });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare("select * from users where username = ?").get(username);
  if (!user) return res.status(401).json({ error: "bad credentials" });
  if (!bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "bad credentials" });
  res.json({ token: signToken(user), user: { id: user.id, username: user.username, coins: user.coins } });
});

app.get("/api/me", auth, (req, res) => {
  const me = db.prepare("select id, username, coins from users where id = ?").get(req.user.uid);
  res.json(me);
});

app.get("/api/bets", (_req, res) => {
  const rows = db
    .prepare(`select id, sport, event, market, selection, odds_decimal, starts_at
              from bets where status = 'open' order by starts_at asc`)
    .all();
  res.json(rows);
});

app.post("/api/wagers", auth, (req, res) => {
  const { betId, stake } = req.body || {};
  const MIN = 8, MAX = 30;
  if (!Number.isInteger(stake)) return res.status(400).json({ error: "stake must be an integer" });
  if (stake < MIN || stake > MAX) return res.status(400).json({ error: `stake must be between ${MIN}-${MAX}` });

  const user = db.prepare("select id, coins from users where id = ?").get(req.user.uid);
  if (!user) return res.status(404).json({ error: "user not found" });
  if (user.coins < stake) return res.status(400).json({ error: "insufficient coins" });
  if (user.coins <= 0) return res.status(403).json({ error: "you are out of coins and cannot bet" });

  const bet = db.prepare("select * from bets where id = ? and status = 'open'").get(betId);
  if (!bet) return res.status(404).json({ error: "bet not found or closed" });

  const potential = +(stake * bet.odds_decimal).toFixed(2);

  const tx = db.transaction(() => {
    db.prepare("update users set coins = coins - ? where id = ?").run(stake, user.id);
    const info = db.prepare(`
      insert into wagers (user_id, bet_id, stake, potential_payout, status, placed_at)
      values (?,?,?,?, 'pending', datetime('now'))
    `).run(user.id, bet.id, stake, potential);
    return info.lastInsertRowid;
  });

  const id = tx();
  const me = db.prepare("select id, username, coins from users where id = ?").get(user.id);
  res.json({ ok: true, wagerId: id, coinsRemaining: me.coins, potentialPayout: potential });
});

app.get("/api/leaderboard", (_req, res) => {
  const rows = db.prepare("select username, coins from users order by coins desc, username asc limit 100").all();
  const meta = db.prepare("select value from meta where key = 'leaderboard_last_updated'").get();
  res.json({ lastUpdated: meta?.value || null, users: rows });
});

app.post("/api/admin/seed-bets", (_req, res) => {
  const now = new Date();
  const seeds = [
    { sport: "MLB", event: "NY Yankees @ BOS Red Sox", market: "Moneyline", selection: "Yankees", odds: 1.80, startsInHrs: 6 },
    { sport: "MLB", event: "LA Dodgers @ SF Giants", market: "Total Runs", selection: "Over 8.5", odds: 1.95, startsInHrs: 9 },
    { sport: "Tennis", event: "US Open Qualifier", market: "Match Winner", selection: "Player A", odds: 2.10, startsInHrs: 27 },
    { sport: "Soccer", event: "Arsenal vs Chelsea", market: "Both Teams to Score", selection: "Yes", odds: 1.72, startsInHrs: 30 }
  ];

  const insert = db.prepare(`
    insert into bets (sport,event,market,selection,odds_decimal,status,starts_at)
    values (?,?,?,?,?,'open',?)
  `);

  const tx = db.transaction(() => {
    for (const s of seeds) {
      const starts = new Date(now.getTime() + s.startsInHrs * 3600_000).toISOString().slice(0, 19).replace("T", " ");
      insert.run(s.sport, s.event, s.market, s.selection, s.odds, starts);
    }
  });
  tx();
  res.json({ ok: true, added: seeds.length });
});

app.listen(PORT, () => {
  console.log(`server on :${PORT}`);
});

setInterval(() => {
  db.prepare("insert into meta(key,value) values('leaderboard_last_updated', datetime('now')) on conflict(key) do update set value = excluded.value").run();
}, 60 * 60 * 1000);
db.prepare("insert into meta(key,value) values('leaderboard_last_updated', datetime('now')) on conflict(key) do update set value = excluded.value").run();